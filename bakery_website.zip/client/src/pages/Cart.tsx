import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { Loader2, Trash2 } from "lucide-react";
import { useState } from "react";

export default function Cart() {
  const { isAuthenticated } = useAuth();
  const { data: cart, isLoading } = trpc.cart.list.useQuery();
  const { data: menuItems } = trpc.menu.list.useQuery();
  const removeFromCart = trpc.cart.remove.useMutation();
  const createOrder = trpc.orders.create.useMutation();
  const [notes, setNotes] = useState("");

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-paper flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-sketch-header text-4xl mb-4">Please Sign In</h1>
          <p className="text-foreground/70 font-courier-prime mb-6">You need to be signed in to view your cart</p>
          <Button asChild>
            <Link href="/"><a>Go Home</a></Link>
          </Button>
        </div>
      </div>
    );
  }

  const getMenuItem = (itemId: number) => {
    return menuItems?.find(item => item.id === itemId);
  };

  const calculateTotal = () => {
    if (!cart) return 0;
    return cart.reduce((sum, cartItem) => {
      const menuItem = getMenuItem(cartItem.menuItemId);
      return sum + (menuItem ? menuItem.price * cartItem.quantity : 0);
    }, 0) / 100;
  };

  const handleCheckout = () => {
    if (!cart || cart.length === 0) return;

    const items = cart.map(cartItem => ({
      menuItemId: cartItem.menuItemId,
      quantity: cartItem.quantity
    }));

    const totalPrice = Math.round(calculateTotal() * 100);

    createOrder.mutate({ items, totalPrice, notes }, {
      onSuccess: (result) => {
        if (result.success && result.orderId) {
          window.location.href = `/order-confirmation?orderId=${result.orderId}`;
        } else {
          window.location.href = "/orders";
        }
      }
    });
  };

  return (
    <div className="min-h-screen bg-paper">
      {/* Navigation */}
      <nav className="border-b-2 border-foreground/20 bg-card/50 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2 no-underline">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_logo-JGzkHr7iGBTfZnqQNbqC5y.webp"
                alt="Countryside Bakery"
                className="h-10 w-10"
              />
              <span className="text-sketch-header text-xl">Countryside Bakery</span>
            </a>
          </Link>
          <div className="flex gap-4">
            <Link href="/menu"><a className="font-caveat font-bold">Menu</a></Link>
            <Link href="/cart"><a className="font-caveat font-bold">Cart</a></Link>
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="border-b-2 border-foreground/20 py-12">
        <div className="container">
          <h1 className="text-sketch-header text-5xl mb-2">Shopping Cart</h1>
          <p className="text-foreground/70 font-courier-prime">Review your items before checkout</p>
        </div>
      </section>

      {/* Cart Content */}
      <section className="py-12">
        <div className="container">
          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="animate-spin w-8 h-8" />
            </div>
          ) : !cart || cart.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-foreground/60 font-courier-prime mb-6">Your cart is empty</p>
              <Button asChild className="btn-sketch">
                <Link href="/menu"><a>Continue Shopping</a></Link>
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2 space-y-4">
                {cart.map(cartItem => {
                  const menuItem = getMenuItem(cartItem.menuItemId);
                  if (!menuItem) return null;

                  const itemTotal = (menuItem.price * cartItem.quantity) / 100;

                  return (
                    <div key={cartItem.id} className="sketch-card p-6 flex gap-4">
                      <div className="flex-1">
                        <h3 className="text-sketch-subheader text-xl mb-2">{menuItem.name}</h3>
                        <p className="text-foreground/70 font-courier-prime text-sm mb-4">{menuItem.description}</p>
                        <div className="flex items-center gap-4">
                          <span className="text-lg font-bold">${(menuItem.price / 100).toFixed(2)} x {cartItem.quantity}</span>
                          <span className="text-lg font-bold text-accent">${itemTotal.toFixed(2)}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => removeFromCart.mutate({ cartItemId: cartItem.id })}
                        className="text-destructive hover:text-destructive/80 transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Order Summary */}
              <div className="sketch-card p-6 h-fit sticky top-4 space-y-6">
                <h2 className="text-sketch-subheader text-2xl">Order Summary</h2>

                <div className="space-y-3 border-b-2 border-foreground/20 pb-4">
                  <div className="flex justify-between">
                    <span className="text-foreground/70">Subtotal:</span>
                    <span className="font-bold">${calculateTotal().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-foreground/70">Tax:</span>
                    <span className="font-bold">$0.00</span>
                  </div>
                </div>

                <div className="flex justify-between text-lg">
                  <span className="font-bold">Total:</span>
                  <span className="font-bold text-accent text-2xl">${calculateTotal().toFixed(2)}</span>
                </div>

                {/* Notes */}
                <div className="space-y-2">
                  <label className="block text-foreground font-caveat font-bold">Special Notes (Optional)</label>
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Any special requests or dietary notes?"
                    className="w-full p-3 border-2 border-foreground/30 rounded font-courier-prime text-sm"
                    rows={3}
                  />
                </div>

                {/* Checkout Button */}
                <Button
                  onClick={handleCheckout}
                  disabled={createOrder.isPending}
                  className="w-full btn-sketch"
                >
                  {createOrder.isPending ? "Processing..." : "Proceed to Checkout"}
                </Button>

                <Button asChild variant="outline" className="w-full border-2">
                  <Link href="/menu"><a>Continue Shopping</a></Link>
                </Button>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t-2 border-foreground/20 bg-card/50 py-8 mt-12">
        <div className="container text-center">
          <p className="text-foreground/60 font-courier-prime">
            © 2026 Countryside Bakery. Handcrafted with ❤️ in the countryside.
          </p>
        </div>
      </footer>
    </div>
  );
}
