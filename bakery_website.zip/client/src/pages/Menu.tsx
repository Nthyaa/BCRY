import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";
import { useState } from "react";
import { Loader2, ShoppingCart } from "lucide-react";

export default function Menu() {
  const { isAuthenticated } = useAuth();
  const { data: menuItems, isLoading } = trpc.menu.list.useQuery();
  const { data: discounts } = trpc.discounts.list.useQuery();
  const addToCart = trpc.cart.add.useMutation();
  const [quantities, setQuantities] = useState<Record<number, number>>({});

  const getDiscountForItem = (itemId: number) => {
    return discounts?.find(d => d.menuItemId === itemId);
  };

  const handleAddToCart = (itemId: number) => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }
    const quantity = quantities[itemId] || 1;
    addToCart.mutate({ menuItemId: itemId, quantity });
    setQuantities(prev => ({ ...prev, [itemId]: 1 }));
  };

  return (
    <div className="min-h-screen bg-paper">
      {/* Navigation */}
      <nav className="border-b-2 border-foreground/20 bg-card/50 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2 no-underline">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_logo-JGzkHr7iGBTfZnqQNbqC5y.webp"
                alt="Countryside Bakery"
                className="h-10 w-10"
              />
              <span className="text-sketch-header text-xl">Countryside Bakery</span>
            </a>
          </Link>
          <div className="flex gap-4">
            <Link href="/menu"><a className="font-caveat font-bold">Menu</a></Link>
            <Link href="/discounts"><a className="font-caveat font-bold">Discounts</a></Link>
            {isAuthenticated && <Link href="/cart"><a className="font-caveat font-bold">Cart</a></Link>}
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="border-b-2 border-foreground/20 py-12">
        <div className="container">
          <h1 className="text-sketch-header text-5xl mb-2">Today's Menu</h1>
          <p className="text-foreground/70 font-courier-prime">Fresh baked goods available today</p>
        </div>
      </section>

      {/* Menu Items */}
      <section className="py-12">
        <div className="container">
          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="animate-spin w-8 h-8" />
            </div>
          ) : !menuItems || menuItems.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-foreground/60 font-courier-prime">No items available today</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {menuItems.map(item => {
                const discount = getDiscountForItem(item.id);
                const originalPrice = item.price / 100;
                const discountedPrice = discount ? (originalPrice * (100 - discount.discountPercentage)) / 100 : originalPrice;

                return (
                  <div key={item.id} className="sketch-card overflow-hidden hover:shadow-lg transition-shadow">
                    {/* Item Image */}
                    <div className="relative bg-background/50 h-48 flex items-center justify-center overflow-hidden">
                      {item.imageUrl ? (
                        <img 
                          src={item.imageUrl} 
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <img 
                          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/menu_item_placeholder-gih2RStQ6Mt3MWTxw9pdov.webp"
                          alt="Menu item"
                          className="w-full h-full object-cover"
                        />
                      )}
                      {discount && (
                        <div className="absolute top-3 right-3">
                          <img 
                            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/discount_badge-HfWdKWC4McRthjD5yAduP5.webp"
                            alt={`${discount.discountPercentage}% off`}
                            className="w-16 h-16"
                          />
                        </div>
                      )}
                    </div>

                    {/* Item Details */}
                    <div className="p-6 space-y-4">
                      <div>
                        <h3 className="text-sketch-subheader text-2xl mb-2">{item.name}</h3>
                        <p className="text-foreground/70 font-courier-prime text-sm">{item.description}</p>
                      </div>

                      {/* Pricing */}
                      <div className="flex items-center gap-2">
                        {discount ? (
                          <>
                            <span className="text-lg font-bold text-accent">${discountedPrice.toFixed(2)}</span>
                            <span className="text-sm line-through text-foreground/50">${originalPrice.toFixed(2)}</span>
                          </>
                        ) : (
                          <span className="text-lg font-bold text-foreground">${originalPrice.toFixed(2)}</span>
                        )}
                      </div>

                      {/* Quantity & Add to Cart */}
                      <div className="flex gap-2 items-center">
                        <input
                          type="number"
                          min="1"
                          value={quantities[item.id] || 1}
                          onChange={(e) => setQuantities(prev => ({ ...prev, [item.id]: parseInt(e.target.value) || 1 }))}
                          className="w-16 px-2 py-1 border-2 border-foreground/30 rounded text-center font-courier-prime"
                        />
                        <Button
                          onClick={() => handleAddToCart(item.id)}
                          disabled={addToCart.isPending}
                          className="flex-1 btn-sketch"
                        >
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          Add
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t-2 border-foreground/20 bg-card/50 py-8 mt-12">
        <div className="container text-center">
          <p className="text-foreground/60 font-courier-prime">
            © 2026 Countryside Bakery. Handcrafted with ❤️ in the countryside.
          </p>
        </div>
      </footer>
    </div>
  );
}
