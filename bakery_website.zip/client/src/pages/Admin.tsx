import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { Loader2, Plus, Trash2, Edit2 } from "lucide-react";
import { useState } from "react";

export default function Admin() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<"menu" | "discounts" | "orders">("menu");
  const [showForm, setShowForm] = useState(false);

  // Menu queries and mutations
  const { data: menuItems, isLoading: menuLoading } = trpc.admin.menuList.useQuery();
  const menuCreate = trpc.admin.menuCreate.useMutation();
  const menuDelete = trpc.admin.menuDelete.useMutation();
  const [menuForm, setMenuForm] = useState({ name: "", description: "", price: 0 });

  // Discounts queries and mutations
  const { data: discounts, isLoading: discountsLoading } = trpc.admin.discountsList.useQuery();
  const { data: allMenuItems } = trpc.menu.list.useQuery();
  const discountCreate = trpc.admin.discountCreate.useMutation();
  const discountDelete = trpc.admin.discountDelete.useMutation();
  const [discountForm, setDiscountForm] = useState({ menuItemId: 0, discountPercentage: 0 });

  // Orders queries and mutations
  const { data: allOrders, isLoading: ordersLoading } = trpc.admin.ordersList.useQuery();
  const orderUpdate = trpc.admin.orderUpdate.useMutation();

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-paper flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-sketch-header text-4xl mb-4">Access Denied</h1>
          <p className="text-foreground/70 font-courier-prime mb-6">You need admin privileges to access this page</p>
          <Button asChild>
            <Link href="/"><a>Go Home</a></Link>
          </Button>
        </div>
      </div>
    );
  }

  const getMenuItemName = (itemId: number) => {
    return allMenuItems?.find(item => item.id === itemId)?.name || `Item #${itemId}`;
  };

  const handleMenuCreate = () => {
    menuCreate.mutate({
      name: menuForm.name,
      description: menuForm.description,
      price: Math.round(menuForm.price * 100),
    }, {
      onSuccess: () => {
        setMenuForm({ name: "", description: "", price: 0 });
        setShowForm(false);
      }
    });
  };

  const handleDiscountCreate = () => {
    if (discountForm.menuItemId === 0) return;
    discountCreate.mutate({
      menuItemId: discountForm.menuItemId,
      discountPercentage: discountForm.discountPercentage,
    }, {
      onSuccess: () => {
        setDiscountForm({ menuItemId: 0, discountPercentage: 0 });
        setShowForm(false);
      }
    });
  };

  return (
    <div className="min-h-screen bg-paper">
      {/* Navigation */}
      <nav className="border-b-2 border-foreground/20 bg-card/50 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2 no-underline">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_logo-JGzkHr7iGBTfZnqQNbqC5y.webp"
                alt="Countryside Bakery"
                className="h-10 w-10"
              />
              <span className="text-sketch-header text-xl">Admin Panel</span>
            </a>
          </Link>
          <Button asChild variant="outline">
            <Link href="/"><a>Back to Store</a></Link>
          </Button>
        </div>
      </nav>

      {/* Admin Content */}
      <div className="container py-12">
        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b-2 border-foreground/20 pb-4">
          {(["menu", "discounts", "orders"] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 font-caveat font-bold text-lg transition-colors ${
                activeTab === tab
                  ? "text-accent border-b-2 border-accent"
                  : "text-foreground/60 hover:text-foreground"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Menu Management */}
        {activeTab === "menu" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-sketch-subheader text-3xl">Menu Items</h2>
              <Button onClick={() => setShowForm(!showForm)} className="btn-sketch">
                <Plus className="w-4 h-4 mr-2" />
                Add Item
              </Button>
            </div>

            {showForm && (
              <div className="sketch-card p-6 space-y-4">
                <input
                  type="text"
                  placeholder="Item Name"
                  value={menuForm.name}
                  onChange={(e) => setMenuForm({ ...menuForm, name: e.target.value })}
                  className="w-full px-3 py-2 border-2 border-foreground/30 rounded font-courier-prime"
                />
                <textarea
                  placeholder="Description"
                  value={menuForm.description}
                  onChange={(e) => setMenuForm({ ...menuForm, description: e.target.value })}
                  className="w-full px-3 py-2 border-2 border-foreground/30 rounded font-courier-prime"
                  rows={3}
                />
                <input
                  type="number"
                  placeholder="Price"
                  value={menuForm.price}
                  onChange={(e) => setMenuForm({ ...menuForm, price: parseFloat(e.target.value) })}
                  className="w-full px-3 py-2 border-2 border-foreground/30 rounded font-courier-prime"
                  step="0.01"
                />
                <div className="flex gap-2">
                  <Button onClick={handleMenuCreate} disabled={menuCreate.isPending} className="btn-sketch">
                    Create
                  </Button>
                  <Button onClick={() => setShowForm(false)} variant="outline" className="border-2">
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            {menuLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="animate-spin w-8 h-8" />
              </div>
            ) : !menuItems || menuItems.length === 0 ? (
              <p className="text-foreground/60 font-courier-prime">No menu items yet</p>
            ) : (
              <div className="space-y-4">
                {menuItems.map(item => (
                  <div key={item.id} className="sketch-card p-4 flex justify-between items-center">
                    <div>
                      <h3 className="font-bold text-lg">{item.name}</h3>
                      <p className="text-foreground/70 text-sm">${(item.price / 100).toFixed(2)}</p>
                    </div>
                    <button
                      onClick={() => menuDelete.mutate({ id: item.id })}
                      className="text-destructive hover:text-destructive/80"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Discount Management */}
        {activeTab === "discounts" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-sketch-subheader text-3xl">Discounts</h2>
              <Button onClick={() => setShowForm(!showForm)} className="btn-sketch">
                <Plus className="w-4 h-4 mr-2" />
                Add Discount
              </Button>
            </div>

            {showForm && (
              <div className="sketch-card p-6 space-y-4">
                <select
                  value={discountForm.menuItemId}
                  onChange={(e) => setDiscountForm({ ...discountForm, menuItemId: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border-2 border-foreground/30 rounded font-courier-prime"
                >
                  <option value={0}>Select Item</option>
                  {allMenuItems?.map(item => (
                    <option key={item.id} value={item.id}>{item.name}</option>
                  ))}
                </select>
                <input
                  type="number"
                  placeholder="Discount %"
                  value={discountForm.discountPercentage}
                  onChange={(e) => setDiscountForm({ ...discountForm, discountPercentage: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border-2 border-foreground/30 rounded font-courier-prime"
                  min="0"
                  max="100"
                />
                <div className="flex gap-2">
                  <Button onClick={handleDiscountCreate} disabled={discountCreate.isPending} className="btn-sketch">
                    Create
                  </Button>
                  <Button onClick={() => setShowForm(false)} variant="outline" className="border-2">
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            {discountsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="animate-spin w-8 h-8" />
              </div>
            ) : !discounts || discounts.length === 0 ? (
              <p className="text-foreground/60 font-courier-prime">No discounts yet</p>
            ) : (
              <div className="space-y-4">
                {discounts.map(discount => (
                  <div key={discount.id} className="sketch-card p-4 flex justify-between items-center">
                    <div>
                      <h3 className="font-bold text-lg">{getMenuItemName(discount.menuItemId)}</h3>
                      <p className="text-foreground/70 text-sm">{discount.discountPercentage}% OFF</p>
                    </div>
                    <button
                      onClick={() => discountDelete.mutate({ id: discount.id })}
                      className="text-destructive hover:text-destructive/80"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Order Management */}
        {activeTab === "orders" && (
          <div className="space-y-6">
            <h2 className="text-sketch-subheader text-3xl">Orders</h2>

            {ordersLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="animate-spin w-8 h-8" />
              </div>
            ) : !allOrders || allOrders.length === 0 ? (
              <p className="text-foreground/60 font-courier-prime">No orders yet</p>
            ) : (
              <div className="space-y-4">
                {allOrders.map(order => (
                  <div key={order.id} className="sketch-card p-6 space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-bold text-lg">Order #{order.id}</h3>
                        <p className="text-foreground/70 text-sm">Total: ${(order.totalPrice / 100).toFixed(2)}</p>
                      </div>
                      <select
                        value={order.status}
                        onChange={(e) => orderUpdate.mutate({ id: order.id, status: e.target.value as any })}
                        className="px-3 py-2 border-2 border-foreground/30 rounded font-courier-prime"
                      >
                        <option value="pending">Pending</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="ready">Ready</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </div>
                    {order.notes && (
                      <p className="text-sm text-foreground/70 bg-background/50 p-2 rounded">
                        <span className="font-bold">Notes:</span> {order.notes}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t-2 border-foreground/20 bg-card/50 py-8 mt-12">
        <div className="container text-center">
          <p className="text-foreground/60 font-courier-prime">
            © 2026 Countryside Bakery Admin Panel
          </p>
        </div>
      </footer>
    </div>
  );
}
