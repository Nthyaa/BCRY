import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Loader2, LogOut } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";

export default function Profile() {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const logoutMutation = trpc.auth.logout.useMutation();

  if (loading) {
    return (
      <div className="min-h-screen bg-paper flex items-center justify-center">
        <Loader2 className="animate-spin w-8 h-8" />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen bg-paper">
        <nav className="border-b-2 border-foreground/20 bg-card/50 backdrop-blur-sm">
          <div className="container flex items-center justify-between py-4">
            <Link href="/">
              <a className="flex items-center gap-2 no-underline">
                <img 
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_logo-JGzkHr7iGBTfZnqQNbqC5y.webp"
                  alt="Countryside Bakery"
                  className="h-10 w-10"
                />
                <span className="text-sketch-header text-xl">My Account</span>
              </a>
            </Link>
          </div>
        </nav>

        <div className="container py-12 flex flex-col items-center justify-center min-h-[60vh]">
          <div className="text-center space-y-6">
            <h1 className="text-sketch-header text-4xl">Sign In Required</h1>
            <p className="text-foreground/70 font-courier-prime max-w-md">
              Please sign in to view your account details, orders, and manage your profile.
            </p>
            <Button asChild className="btn-sketch">
              <a href={getLoginUrl()}>Sign In with Manus</a>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        logout();
      }
    });
  };

  return (
    <div className="min-h-screen bg-paper">
      {/* Navigation */}
      <nav className="border-b-2 border-foreground/20 bg-card/50 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2 no-underline">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_logo-JGzkHr7iGBTfZnqQNbqC5y.webp"
                alt="Countryside Bakery"
                className="h-10 w-10"
              />
              <span className="text-sketch-header text-xl">My Account</span>
            </a>
          </Link>
          <div className="flex gap-4">
            <Button asChild variant="outline" className="border-2">
              <Link href="/orders"><a>My Orders</a></Link>
            </Button>
            <Button 
              onClick={handleLogout}
              disabled={logoutMutation.isPending}
              variant="destructive"
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>
      </nav>

      {/* Profile Content */}
      <div className="container py-12">
        <div className="max-w-2xl mx-auto space-y-8">
          {/* Profile Card */}
          <div className="sketch-card p-8 space-y-6">
            <h2 className="text-sketch-subheader text-3xl">Account Details</h2>
            
            <div className="space-y-4">
              {/* Name */}
              <div className="border-b-2 border-foreground/20 pb-4">
                <label className="text-foreground/60 font-courier-prime text-sm">Full Name</label>
                <p className="text-lg font-bold mt-2">{user.name || "Not provided"}</p>
              </div>

              {/* Email */}
              <div className="border-b-2 border-foreground/20 pb-4">
                <label className="text-foreground/60 font-courier-prime text-sm">Email Address</label>
                <p className="text-lg font-bold mt-2">{user.email || "Not provided"}</p>
              </div>

              {/* User ID */}
              <div className="border-b-2 border-foreground/20 pb-4">
                <label className="text-foreground/60 font-courier-prime text-sm">User ID</label>
                <p className="text-lg font-bold mt-2 font-courier-prime">{user.openId}</p>
              </div>

              {/* Member Since */}
              <div className="border-b-2 border-foreground/20 pb-4">
                <label className="text-foreground/60 font-courier-prime text-sm">Member Since</label>
                <p className="text-lg font-bold mt-2">
                  {new Date(user.createdAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
              </div>

              {/* Last Signed In */}
              <div>
                <label className="text-foreground/60 font-courier-prime text-sm">Last Signed In</label>
                <p className="text-lg font-bold mt-2">
                  {new Date(user.lastSignedIn).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </p>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="sketch-card p-8 space-y-4">
            <h3 className="text-sketch-subheader text-2xl">Quick Links</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button asChild className="btn-sketch w-full justify-center">
                <Link href="/menu"><a>Browse Menu</a></Link>
              </Button>
              <Button asChild className="btn-sketch w-full justify-center">
                <Link href="/discounts"><a>View Discounts</a></Link>
              </Button>
              <Button asChild className="btn-sketch w-full justify-center">
                <Link href="/cart"><a>My Cart</a></Link>
              </Button>
              <Button asChild className="btn-sketch w-full justify-center">
                <Link href="/orders"><a>My Orders</a></Link>
              </Button>
            </div>
          </div>

          {/* Account Info */}
          <div className="sketch-card p-8 space-y-4 bg-background/30">
            <h3 className="text-sketch-subheader text-2xl">Account Information</h3>
            <p className="text-foreground/70 font-courier-prime">
              Your account is secured with Manus OAuth authentication. All your orders and preferences are safely stored and can be accessed from any device.
            </p>
            <div className="pt-4 border-t-2 border-foreground/20">
              <p className="text-sm text-foreground/60 font-courier-prime">
                Need help? Contact our support team for assistance with your account.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t-2 border-foreground/20 bg-card/50 py-8 mt-12">
        <div className="container text-center">
          <p className="text-foreground/60 font-courier-prime">
            © 2026 Countryside Bakery
          </p>
        </div>
      </footer>
    </div>
  );
}
