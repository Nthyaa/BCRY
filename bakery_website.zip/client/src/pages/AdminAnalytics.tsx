import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { Loader2, TrendingUp, ShoppingCart, Users, Clock } from "lucide-react";

export default function AdminAnalytics() {
  const { user, isAuthenticated } = useAuth();
  const { data: allOrders, isLoading: ordersLoading } = trpc.admin.ordersList.useQuery();
  const { data: allMenuItems, isLoading: menuLoading } = trpc.admin.menuList.useQuery();
  const { data: allDiscounts, isLoading: discountsLoading } = trpc.admin.discountsList.useQuery();

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-paper flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-sketch-header text-4xl mb-4">Access Denied</h1>
          <p className="text-foreground/70 font-courier-prime mb-6">You need admin privileges to access this page</p>
          <Button asChild>
            <Link href="/"><a>Go Home</a></Link>
          </Button>
        </div>
      </div>
    );
  }

  const isLoading = ordersLoading || menuLoading || discountsLoading;

  // Calculate analytics
  const totalOrders = allOrders?.length || 0;
  const totalRevenue = (allOrders?.reduce((sum, order) => sum + order.totalPrice, 0) || 0) / 100;
  const totalMenuItems = allMenuItems?.length || 0;
  const activeDiscounts = allDiscounts?.filter(d => d.active === 1).length || 0;

  const ordersByStatus = {
    pending: allOrders?.filter(o => o.status === "pending").length || 0,
    confirmed: allOrders?.filter(o => o.status === "confirmed").length || 0,
    ready: allOrders?.filter(o => o.status === "ready").length || 0,
    completed: allOrders?.filter(o => o.status === "completed").length || 0,
    cancelled: allOrders?.filter(o => o.status === "cancelled").length || 0,
  };

  const completionRate = totalOrders > 0 
    ? ((ordersByStatus.completed / totalOrders) * 100).toFixed(1)
    : "0";

  return (
    <div className="min-h-screen bg-paper">
      {/* Navigation */}
      <nav className="border-b-2 border-foreground/20 bg-card/50 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2 no-underline">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_logo-JGzkHr7iGBTfZnqQNbqC5y.webp"
                alt="Countryside Bakery"
                className="h-10 w-10"
              />
              <span className="text-sketch-header text-xl">Admin Analytics</span>
            </a>
          </Link>
          <Button asChild variant="outline">
            <Link href="/admin"><a>Back to Admin</a></Link>
          </Button>
        </div>
      </nav>

      {/* Analytics Content */}
      <div className="container py-12">
        <h1 className="text-sketch-header text-4xl mb-12">Business Analytics</h1>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="animate-spin w-8 h-8" />
          </div>
        ) : (
          <div className="space-y-8">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Total Orders */}
              <div className="sketch-card p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sketch-subheader text-lg">Total Orders</h3>
                  <ShoppingCart className="w-6 h-6 text-accent" />
                </div>
                <p className="text-4xl font-bold">{totalOrders}</p>
                <p className="text-foreground/60 font-courier-prime text-sm">All-time orders</p>
              </div>

              {/* Total Revenue */}
              <div className="sketch-card p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sketch-subheader text-lg">Total Revenue</h3>
                  <TrendingUp className="w-6 h-6 text-accent" />
                </div>
                <p className="text-4xl font-bold">${totalRevenue.toFixed(2)}</p>
                <p className="text-foreground/60 font-courier-prime text-sm">All-time revenue</p>
              </div>

              {/* Menu Items */}
              <div className="sketch-card p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sketch-subheader text-lg">Menu Items</h3>
                  <Users className="w-6 h-6 text-accent" />
                </div>
                <p className="text-4xl font-bold">{totalMenuItems}</p>
                <p className="text-foreground/60 font-courier-prime text-sm">Available items</p>
              </div>

              {/* Active Discounts */}
              <div className="sketch-card p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sketch-subheader text-lg">Active Discounts</h3>
                  <Clock className="w-6 h-6 text-accent" />
                </div>
                <p className="text-4xl font-bold">{activeDiscounts}</p>
                <p className="text-foreground/60 font-courier-prime text-sm">Promotions running</p>
              </div>
            </div>

            {/* Order Status Breakdown */}
            <div className="sketch-card p-8 space-y-6">
              <h2 className="text-sketch-subheader text-2xl">Order Status Breakdown</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                <div className="space-y-2">
                  <p className="text-foreground/60 font-courier-prime text-sm">Pending</p>
                  <p className="text-3xl font-bold">{ordersByStatus.pending}</p>
                  <div className="w-full bg-background/50 rounded h-2">
                    <div 
                      className="bg-yellow-500 h-2 rounded" 
                      style={{ width: totalOrders > 0 ? `${(ordersByStatus.pending / totalOrders) * 100}%` : "0%" }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-foreground/60 font-courier-prime text-sm">Confirmed</p>
                  <p className="text-3xl font-bold">{ordersByStatus.confirmed}</p>
                  <div className="w-full bg-background/50 rounded h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded" 
                      style={{ width: totalOrders > 0 ? `${(ordersByStatus.confirmed / totalOrders) * 100}%` : "0%" }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-foreground/60 font-courier-prime text-sm">Ready</p>
                  <p className="text-3xl font-bold">{ordersByStatus.ready}</p>
                  <div className="w-full bg-background/50 rounded h-2">
                    <div 
                      className="bg-green-500 h-2 rounded" 
                      style={{ width: totalOrders > 0 ? `${(ordersByStatus.ready / totalOrders) * 100}%` : "0%" }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-foreground/60 font-courier-prime text-sm">Completed</p>
                  <p className="text-3xl font-bold">{ordersByStatus.completed}</p>
                  <div className="w-full bg-background/50 rounded h-2">
                    <div 
                      className="bg-green-600 h-2 rounded" 
                      style={{ width: totalOrders > 0 ? `${(ordersByStatus.completed / totalOrders) * 100}%` : "0%" }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-foreground/60 font-courier-prime text-sm">Cancelled</p>
                  <p className="text-3xl font-bold">{ordersByStatus.cancelled}</p>
                  <div className="w-full bg-background/50 rounded h-2">
                    <div 
                      className="bg-red-500 h-2 rounded" 
                      style={{ width: totalOrders > 0 ? `${(ordersByStatus.cancelled / totalOrders) * 100}%` : "0%" }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="sketch-card p-8 space-y-6">
              <h2 className="text-sketch-subheader text-2xl">Performance Metrics</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 border-b-2 border-foreground/20 pb-4">
                  <p className="text-foreground/60 font-courier-prime">Order Completion Rate</p>
                  <p className="text-4xl font-bold">{completionRate}%</p>
                  <p className="text-foreground/70 font-courier-prime text-sm">
                    {ordersByStatus.completed} of {totalOrders} orders completed
                  </p>
                </div>

                <div className="space-y-2 border-b-2 border-foreground/20 pb-4">
                  <p className="text-foreground/60 font-courier-prime">Average Order Value</p>
                  <p className="text-4xl font-bold">${totalOrders > 0 ? (totalRevenue / totalOrders).toFixed(2) : "0.00"}</p>
                  <p className="text-foreground/70 font-courier-prime text-sm">
                    Total revenue ÷ Total orders
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="sketch-card p-8 space-y-4">
              <h2 className="text-sketch-subheader text-2xl mb-4">Quick Actions</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button asChild className="btn-sketch w-full">
                  <Link href="/admin"><a>Manage Orders</a></Link>
                </Button>
                <Button asChild className="btn-sketch w-full">
                  <Link href="/admin"><a>Manage Menu</a></Link>
                </Button>
                <Button asChild className="btn-sketch w-full">
                  <Link href="/admin"><a>Manage Discounts</a></Link>
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t-2 border-foreground/20 bg-card/50 py-8 mt-12">
        <div className="container text-center">
          <p className="text-foreground/60 font-courier-prime">
            © 2026 Countryside Bakery Admin Analytics
          </p>
        </div>
      </footer>
    </div>
  );
}
