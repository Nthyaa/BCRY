import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-paper">
      {/* Navigation */}
      <nav className="border-b-2 border-foreground/20 bg-card/50 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2 no-underline">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_logo-JGzkHr7iGBTfZnqQNbqC5y.webp"
                alt="Countryside Bakery"
                className="h-12 w-12"
              />
              <span className="text-sketch-header text-2xl">Countryside Bakery</span>
            </a>
          </Link>
          
          <div className="flex items-center gap-4">
            <Link href="/menu">
              <a className="font-caveat font-bold text-lg hover:text-accent transition-colors">Menu</a>
            </Link>
            <Link href="/discounts">
              <a className="font-caveat font-bold text-lg hover:text-accent transition-colors">Discounts</a>
            </Link>
            {isAuthenticated ? (
              <>
                <Link href="/cart">
                  <a className="font-caveat font-bold text-lg hover:text-accent transition-colors">Cart</a>
                </Link>
                <Link href="/orders">
                  <a className="font-caveat font-bold text-lg hover:text-accent transition-colors">My Orders</a>
                </Link>
                {user?.role === "admin" && (
                  <Link href="/admin">
                    <a className="font-caveat font-bold text-lg hover:text-accent transition-colors">Admin</a>
                  </Link>
                )}
                <Button variant="outline" size="sm" asChild>
                  <a href="/api/auth/logout">Logout</a>
                </Button>
              </>
            ) : (
              <Button asChild>
                <a href={getLoginUrl()}>Sign In</a>
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-6xl md:text-7xl text-foreground">
                Welcome to<br />
                <span className="text-accent">Countryside Bakery</span>
              </h1>
              <p className="text-lg text-foreground/80 font-courier-prime">
                Handcrafted baked goods made with love, fresh ingredients, and a touch of countryside charm. 
                Every item is baked fresh daily in our small-batch oven.
              </p>
              <div className="flex gap-4">
                <Button asChild size="lg" className="btn-sketch">
                  <Link href="/menu">
                    <a>Browse Menu</a>
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="border-2">
                  <Link href="/discounts">
                    <a>View Discounts</a>
                  </Link>
                </Button>
              </div>
            </div>
            
            <div className="flex justify-center">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_hero_background-J4smZFLDQ5okxMzXELfJB7.webp"
                alt="Bakery showcase"
                className="w-full max-w-md rounded-lg shadow-sketch"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 border-t-2 border-b-2 border-foreground/20 bg-card/30">
        <div className="container">
          <h2 className="text-sketch-header text-center mb-12">Why Choose Us?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Fresh Daily",
                description: "Baked fresh every morning with simple, quality ingredients",
                icon: "🥐"
              },
              {
                title: "Artisan Made",
                description: "Small-batch production ensures every item is crafted with care",
                icon: "🍞"
              },
              {
                title: "Local Sourced",
                description: "Supporting local farmers and suppliers from our countryside community",
                icon: "🌾"
              }
            ].map((feature, idx) => (
              <div key={idx} className="sketch-card p-6 text-center">
                <div className="text-5xl mb-4">{feature.icon}</div>
                <h3 className="text-sketch-subheader mb-3">{feature.title}</h3>
                <p className="text-foreground/70 font-courier-prime">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container text-center space-y-6">
          <h2 className="text-sketch-header">Ready to Order?</h2>
          <p className="text-lg text-foreground/80 font-courier-prime max-w-2xl mx-auto">
            Browse our today's menu and place your order. Fresh baked goods delivered or ready for pickup!
          </p>
          {!isAuthenticated && (
            <Button asChild size="lg" className="btn-sketch">
              <a href={getLoginUrl()}>Sign In to Order</a>
            </Button>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t-2 border-foreground/20 bg-card/50 py-8 mt-12">
        <div className="container text-center">
          <p className="text-foreground/60 font-courier-prime">
            © 2026 Countryside Bakery. Handcrafted with ❤️ in the countryside.
          </p>
        </div>
      </footer>
    </div>
  );
}
