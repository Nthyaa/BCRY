import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { Loader2 } from "lucide-react";

export default function Discounts() {
  const { data: discounts, isLoading: discountsLoading } = trpc.discounts.list.useQuery();
  const { data: menuItems, isLoading: itemsLoading } = trpc.menu.list.useQuery();

  const getMenuItem = (itemId: number) => {
    return menuItems?.find(item => item.id === itemId);
  };

  return (
    <div className="min-h-screen bg-paper">
      {/* Navigation */}
      <nav className="border-b-2 border-foreground/20 bg-card/50 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2 no-underline">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_logo-JGzkHr7iGBTfZnqQNbqC5y.webp"
                alt="Countryside Bakery"
                className="h-10 w-10"
              />
              <span className="text-sketch-header text-xl">Countryside Bakery</span>
            </a>
          </Link>
          <div className="flex gap-4">
            <Link href="/menu"><a className="font-caveat font-bold">Menu</a></Link>
            <Link href="/discounts"><a className="font-caveat font-bold">Discounts</a></Link>
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="border-b-2 border-foreground/20 py-12 bg-gradient-to-br from-accent/10 to-background">
        <div className="container">
          <h1 className="text-sketch-header text-5xl mb-2">Special Discounts</h1>
          <p className="text-foreground/70 font-courier-prime">Don't miss our amazing deals on selected items!</p>
        </div>
      </section>

      {/* Discounts Grid */}
      <section className="py-12">
        <div className="container">
          {discountsLoading || itemsLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="animate-spin w-8 h-8" />
            </div>
          ) : !discounts || discounts.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-foreground/60 font-courier-prime">No discounts available right now</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {discounts.map(discount => {
                const item = getMenuItem(discount.menuItemId);
                if (!item) return null;

                const originalPrice = item.price / 100;
                const discountedPrice = (originalPrice * (100 - discount.discountPercentage)) / 100;
                const savings = originalPrice - discountedPrice;

                return (
                  <div key={discount.id} className="sketch-card overflow-hidden hover:shadow-lg transition-shadow">
                    {/* Item Image */}
                    <div className="relative bg-background/50 h-48 flex items-center justify-center overflow-hidden">
                      {item.imageUrl ? (
                        <img 
                          src={item.imageUrl} 
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <img 
                          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/menu_item_placeholder-gih2RStQ6Mt3MWTxw9pdov.webp"
                          alt="Menu item"
                          className="w-full h-full object-cover"
                        />
                      )}
                      {/* Discount Badge */}
                      <div className="absolute top-3 right-3 flex items-center justify-center">
                        <img 
                          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/discount_badge-HfWdKWC4McRthjD5yAduP5.webp"
                          alt={`${discount.discountPercentage}% off`}
                          className="w-20 h-20"
                        />
                      </div>
                    </div>

                    {/* Item Details */}
                    <div className="p-6 space-y-4">
                      <div>
                        <h3 className="text-sketch-subheader text-2xl mb-2">{item.name}</h3>
                        <p className="text-foreground/70 font-courier-prime text-sm">{item.description}</p>
                      </div>

                      {/* Discount Info */}
                      <div className="bg-accent/10 border-2 border-dashed border-accent p-4 rounded space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-foreground/70 font-courier-prime">Original Price:</span>
                          <span className="line-through text-foreground/50">${originalPrice.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-foreground/70 font-courier-prime">Discount:</span>
                          <span className="font-bold text-accent">{discount.discountPercentage}% OFF</span>
                        </div>
                        <div className="border-t-2 border-dashed border-accent pt-2 flex justify-between items-center">
                          <span className="text-foreground font-bold">Now:</span>
                          <span className="text-2xl font-bold text-accent">${discountedPrice.toFixed(2)}</span>
                        </div>
                        <div className="text-sm text-foreground/60 font-courier-prime">
                          Save ${savings.toFixed(2)}!
                        </div>
                      </div>

                      {/* CTA */}
                      <Button asChild className="w-full btn-sketch">
                        <Link href="/menu">
                          <a>Order Now</a>
                        </Link>
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t-2 border-foreground/20 bg-card/50 py-8 mt-12">
        <div className="container text-center">
          <p className="text-foreground/60 font-courier-prime">
            © 2026 Countryside Bakery. Handcrafted with ❤️ in the countryside.
          </p>
        </div>
      </footer>
    </div>
  );
}
