import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { Loader2 } from "lucide-react";

export default function Orders() {
  const { isAuthenticated } = useAuth();
  const { data: orders, isLoading } = trpc.orders.list.useQuery();
  const { data: menuItems } = trpc.menu.list.useQuery();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-paper flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-sketch-header text-4xl mb-4">Please Sign In</h1>
          <p className="text-foreground/70 font-courier-prime mb-6">You need to be signed in to view your orders</p>
          <Button asChild>
            <Link href="/"><a>Go Home</a></Link>
          </Button>
        </div>
      </div>
    );
  }

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "confirmed": return "bg-blue-100 text-blue-800";
      case "ready": return "bg-green-100 text-green-800";
      case "completed": return "bg-green-200 text-green-900";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusLabel = (status: string) => {
    switch(status) {
      case "pending": return "Pending";
      case "confirmed": return "Confirmed";
      case "ready": return "Ready for Pickup";
      case "completed": return "Completed";
      case "cancelled": return "Cancelled";
      default: return status;
    }
  };

  return (
    <div className="min-h-screen bg-paper">
      {/* Navigation */}
      <nav className="border-b-2 border-foreground/20 bg-card/50 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2 no-underline">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_logo-JGzkHr7iGBTfZnqQNbqC5y.webp"
                alt="Countryside Bakery"
                className="h-10 w-10"
              />
              <span className="text-sketch-header text-xl">Countryside Bakery</span>
            </a>
          </Link>
          <div className="flex gap-4">
            <Link href="/menu"><a className="font-caveat font-bold">Menu</a></Link>
            <Link href="/cart"><a className="font-caveat font-bold">Cart</a></Link>
            <Link href="/orders"><a className="font-caveat font-bold">Orders</a></Link>
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="border-b-2 border-foreground/20 py-12">
        <div className="container">
          <h1 className="text-sketch-header text-5xl mb-2">My Orders</h1>
          <p className="text-foreground/70 font-courier-prime">Track your order status and history</p>
        </div>
      </section>

      {/* Orders List */}
      <section className="py-12">
        <div className="container">
          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="animate-spin w-8 h-8" />
            </div>
          ) : !orders || orders.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-foreground/60 font-courier-prime mb-6">You haven't placed any orders yet</p>
              <Button asChild className="btn-sketch">
                <Link href="/menu"><a>Start Shopping</a></Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              {orders.map(order => (
                <div key={order.id} className="sketch-card p-6 space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-sketch-subheader text-xl mb-1">Order #{order.id}</h3>
                      <p className="text-foreground/60 font-courier-prime text-sm">
                        {formatDate(order.createdAt)}
                      </p>
                    </div>
                    <span className={`px-4 py-2 rounded font-bold text-sm ${getStatusColor(order.status)}`}>
                      {getStatusLabel(order.status)}
                    </span>
                  </div>

                  {/* Order Total */}
                  <div className="border-t-2 border-foreground/20 pt-4 flex justify-between items-center">
                    <span className="text-foreground font-bold">Total:</span>
                    <span className="text-2xl font-bold text-accent">${(order.totalPrice / 100).toFixed(2)}</span>
                  </div>

                  {/* Notes */}
                  {order.notes && (
                    <div className="bg-background/50 p-3 rounded border-2 border-foreground/20">
                      <p className="text-sm font-courier-prime text-foreground/70">
                        <span className="font-bold">Notes:</span> {order.notes}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t-2 border-foreground/20 bg-card/50 py-8 mt-12">
        <div className="container text-center">
          <p className="text-foreground/60 font-courier-prime">
            © 2026 Countryside Bakery. Handcrafted with ❤️ in the countryside.
          </p>
        </div>
      </footer>
    </div>
  );
}
