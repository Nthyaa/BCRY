import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { CheckCircle2 } from "lucide-react";

export default function OrderConfirmation() {
  const [location] = useLocation();
  const orderId = new URLSearchParams(location.split("?")[1]).get("orderId");

  return (
    <div className="min-h-screen bg-paper">
      {/* Navigation */}
      <nav className="border-b-2 border-foreground/20 bg-card/50 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <a className="flex items-center gap-2 no-underline">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663609935834/EKvJk26adNqMhA3BoZnvvn/bakery_logo-JGzkHr7iGBTfZnqQNbqC5y.webp"
                alt="Countryside Bakery"
                className="h-10 w-10"
              />
              <span className="text-sketch-header text-xl">Order Confirmation</span>
            </a>
          </Link>
        </div>
      </nav>

      {/* Confirmation Content */}
      <div className="container py-12 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="max-w-md text-center space-y-8">
          {/* Success Icon */}
          <div className="flex justify-center">
            <div className="relative">
              <div className="absolute inset-0 bg-accent/20 rounded-full blur-xl"></div>
              <CheckCircle2 className="w-24 h-24 text-accent relative" />
            </div>
          </div>

          {/* Confirmation Message */}
          <div className="space-y-4">
            <h1 className="text-sketch-header text-4xl">Order Confirmed!</h1>
            <p className="text-foreground/70 font-courier-prime">
              Thank you for your order. We're preparing your delicious baked goods!
            </p>
          </div>

          {/* Order Details */}
          {orderId && (
            <div className="sketch-card p-6 space-y-3 bg-background/50">
              <p className="text-foreground/60 font-courier-prime text-sm">Order Number</p>
              <p className="text-2xl font-bold font-courier-prime">#{orderId}</p>
              <p className="text-foreground/60 font-courier-prime text-sm">
                You can track your order status in "My Orders"
              </p>
            </div>
          )}

          {/* Next Steps */}
          <div className="space-y-3 pt-4">
            <p className="text-foreground/70 font-courier-prime text-sm">
              Your order will be ready for pickup or delivery soon. We'll notify you when it's ready!
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-3 pt-4">
            <Button asChild className="btn-sketch w-full">
              <Link href="/orders"><a>View My Orders</a></Link>
            </Button>
            <Button asChild variant="outline" className="border-2 w-full">
              <Link href="/menu"><a>Continue Shopping</a></Link>
            </Button>
            <Button asChild variant="outline" className="border-2 w-full">
              <Link href="/"><a>Back to Home</a></Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t-2 border-foreground/20 bg-card/50 py-8 mt-12">
        <div className="container text-center">
          <p className="text-foreground/60 font-courier-prime">
            © 2026 Countryside Bakery
          </p>
        </div>
      </footer>
    </div>
  );
}
